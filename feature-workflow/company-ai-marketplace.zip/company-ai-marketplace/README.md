# Company AI Marketplace

公司内部 AI 技能与工具市场，基于 Claude Code Plugin 体系。

## 安装

两种方式，任选其一。

### 方式一：Claude Code 原生命令（推荐）

```bash
# 1. 添加市场源（只需一次）
claude plugin marketplace add http://119.119.119.4:9090/meper/meper-claude-marketplace

# 2. 安装插件
claude plugin install feature-workflow
```

更新时：
```bash
claude plugin update feature-workflow
```

### 方式二：本地脚本安装

```bash
# 1. 克隆仓库
git clone http://119.119.119.4:9090/meper/meper-claude-marketplace.git
cd meper-claude-marketplace

# 2. 安装到目标项目（复制 skills/commands/agents 到 .claude/）
./scripts/install-plugin.sh /path/to/your/project
```

更新时重新 clone 再跑一次脚本即可。

## 初始化项目

安装完成后，在项目中初始化 Feature Workflow：

### 方式一：在 Claude Code 中

```
/init-project
```

### 方式二：命令行脚本

```bash
# 交互模式（带确认）
/path/to/meper-claude-marketplace/scripts/init-project.sh

# 快速模式（跳过确认，全用默认值）
/path/to/meper-claude-marketplace/scripts/init-project.sh --quick

# 指定参数
/path/to/meper-claude-marketplace/scripts/init-project.sh --name=MyProject --tech=python-311 --test=pytest
```

初始化会自动创建：
- `feature-workflow/config.yaml` — 项目配置
- `feature-workflow/queue.yaml` — 调度队列
- `features/` — 需求目录
- `features/archive/archive-log.yaml` — 归档日志
- `project-context.md` — 项目上下文

## 使用

```
/new-feature 添加用户认证功能    # 创建需求
/start-feature feat-user-auth   # 启动开发
/dev-agent feat-user-auth       # 自动开发
/list-features                  # 查看列表
```

## 管理命令

```bash
# 查看已安装的插件
claude plugin list

# 禁用 / 启用
claude plugin disable feature-workflow
claude plugin enable feature-workflow

# 卸载
claude plugin uninstall feature-workflow

# 更新市场源索引
claude plugin marketplace update
```

## 架构

```
company-ai-marketplace/
├── .claude-plugin/
│   └── marketplace.json           # 市场索引
├── plugins/
│   └── feature-workflow/
│       ├── .claude-plugin/
│       │   └── plugin.json        # 插件元数据
│       ├── commands/              # Slash Command
│       │   └── dev-agent.md
│       ├── agents/                # SubAgent
│       │   └── dev-subagent.md
│       ├── skills/                # 技能定义（13 个）
│       │   ├── new-feature.md
│       │   ├── start-feature.md
│       │   ├── implement-feature.md
│       │   ├── verify-feature.md
│       │   ├── complete-feature.md
│       │   ├── list-features.md
│       │   ├── block-feature.md
│       │   ├── unblock-feature.md
│       │   ├── feature-config.md
│       │   ├── cleanup-features.md
│       │   ├── init-project.md
│       │   ├── pm-agent.md
│       │   └── verify-feature.md
│       └── templates/             # 配置模板
│           ├── config.yaml
│           ├── queue.yaml
│           ├── archive-log.yaml
│           ├── spec.md
│           ├── task.md
│           └── checklist.md
├── scripts/
│   ├── install-plugin.sh          # 本地安装脚本
│   └── init-project.sh            # 项目初始化脚本
└── README.md
```

## 组件职责

| 组件 | 用途 |
|------|------|
| **Command** | 调度入口，批量派发 Agent |
| **Agent** | 重度任务处理，独立上下文，防止 Token 溢出 |
| **Skill** | 具体技能，定义单个 Slash Command |

## 版本管理

1. 修改插件代码
2. 更新 `plugin.json` 中的 `version`
3. `git push`
4. 团队成员执行 `claude plugin update feature-workflow`

## 扩展指南

在 `plugins/` 下创建新目录，添加 `.claude-plugin/plugin.json`：

```json
{
  "name": "your-plugin-name",
  "description": "插件描述",
  "version": "1.0.0",
  "author": {
    "name": "Team Name"
  }
}
```

然后在 `marketplace.json` 的 `plugins` 数组中注册即可。
