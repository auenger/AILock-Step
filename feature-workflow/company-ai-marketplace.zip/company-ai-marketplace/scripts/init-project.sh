#!/usr/bin/env bash
# init-project.sh — 在当前项目中初始化 Feature Workflow 系统
#
# 用法:
#   cd /path/to/your/project
#   /path/to/company-ai-marketplace/scripts/init-project.sh [options]
#
# 选项:
#   --name=NAME         项目名称（默认: 当前目录名）
#   --tech=TECH         技术栈（默认: 自动检测）
#   --test=FRAMEWORK    测试框架（默认: 自动检测）
#   --branch=BRANCH     主分支（默认: 自动检测）
#   --parallel=N        最大并行数（默认: 3）
#   --quick             快速模式，跳过交互确认
#   --force             强制重新初始化（备份旧配置）
#
# 功能:
#   1. 检测 Git 仓库和主分支
#   2. 自动检测技术栈和测试框架
#   3. 创建 feature-workflow/config.yaml
#   4. 创建 feature-workflow/queue.yaml
#   5. 创建 features/ 目录结构
#   6. 创建 features/archive/archive-log.yaml
#   7. 创建 project-context.md 模板
#   8. 安装 .claude/ 技能文件（如果通过 marketplace 运行）

set -euo pipefail

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 默认值
PROJECT_NAME=""
TECH_STACK=""
TEST_FRAMEWORK=""
MAIN_BRANCH=""
MAX_PARALLEL=2
QUICK_MODE=false
FORCE_MODE=false

# 解析参数
for arg in "$@"; do
    case $arg in
        --name=*)     PROJECT_NAME="${arg#*=}" ;;
        --tech=*)     TECH_STACK="${arg#*=}" ;;
        --test=*)     TEST_FRAMEWORK="${arg#*=}" ;;
        --branch=*)   MAIN_BRANCH="${arg#*=}" ;;
        --parallel=*) MAX_PARALLEL="${arg#*=}" ;;
        --quick)      QUICK_MODE=true ;;
        --force)      FORCE_MODE=true ;;
        --help|-h)    echo "Usage: $0 [--name=X] [--tech=X] [--test=X] [--branch=X] [--parallel=N] [--quick] [--force]"; exit 0 ;;
        *)            echo -e "${RED}Unknown option: ${arg}${NC}"; exit 1 ;;
    esac
done

echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Feature Workflow - Project Initialization${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""

# ─── Check 1: Git Repository ───
if ! git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
    echo -e "${RED}Error: Not a Git repository${NC}"
    echo "Run 'git init' first."
    exit 1
fi

PROJECT_DIR="$(git rev-parse --show-toplevel)"
cd "${PROJECT_DIR}"
echo -e "  Project dir: ${PROJECT_DIR}"

# ─── Check 2: Already Initialized ───
if [ -f "feature-workflow/config.yaml" ] && [ "${FORCE_MODE}" = false ]; then
    echo -e "${YELLOW}Warning: feature-workflow/config.yaml already exists${NC}"
    echo "Use --force to reinitialize (backup will be created)."
    exit 1
fi

if [ -f "feature-workflow/config.yaml" ] && [ "${FORCE_MODE}" = true ]; then
    BACKUP="feature-workflow/config.yaml.bak.$(date +%Y%m%d%H%M%S)"
    cp "feature-workflow/config.yaml" "${BACKUP}"
    echo -e "  ${YELLOW}Backup: ${BACKUP}${NC}"
fi

# ─── Auto-Detection ───

# Project Name
if [ -z "${PROJECT_NAME}" ]; then
    PROJECT_NAME=$(basename "${PROJECT_DIR}" | sed 's/[-_]//g' | sed 's/\b\(.\)/\u\1/g')
fi

# Main Branch
if [ -z "${MAIN_BRANCH}" ]; then
    MAIN_BRANCH=$(git remote show origin 2>/dev/null | grep 'HEAD branch' | sed 's/.*: //') || true
    if [ -z "${MAIN_BRANCH}" ]; then
        if git show-ref --verify --quiet refs/heads/main; then
            MAIN_BRANCH="main"
        elif git show-ref --verify --quiet refs/heads/master; then
            MAIN_BRANCH="master"
        else
            MAIN_BRANCH="main"
        fi
    fi
fi

# Tech Stack
if [ -z "${TECH_STACK}" ]; then
    if [ -f "pyproject.toml" ]; then
        PYTHON_VER=$(python3 --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+' || echo "3.11")
        TECH_STACK="python-${PYTHON_VER}"
    elif [ -f "package.json" ]; then
        NODE_VER=$(node --version 2>/dev/null | grep -oE '[0-9]+' | head -1 || echo "20")
        TECH_STACK="node-${NODE_VER}"
    elif [ -f "go.mod" ]; then
        GO_VER=$(go version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+' || echo "1.21")
        TECH_STACK="go-${GO_VER}"
    elif [ -f "Cargo.toml" ]; then
        TECH_STACK="rust"
    else
        TECH_STACK="unknown"
    fi
fi

# Test Framework
if [ -z "${TEST_FRAMEWORK}" ]; then
    if echo "${TECH_STACK}" | grep -q "python"; then
        TEST_FRAMEWORK="pytest"
    elif echo "${TECH_STACK}" | grep -q "node"; then
        if [ -f "vitest.config.*" ] || grep -q "vitest" package.json 2>/dev/null; then
            TEST_FRAMEWORK="vitest"
        else
            TEST_FRAMEWORK="jest"
        fi
    elif echo "${TECH_STACK}" | grep -q "go"; then
        TEST_FRAMEWORK="go-testing"
    else
        TEST_FRAMEWORK="unknown"
    fi
fi

# Worktree Prefix
WORKTREE_PREFIX="${PROJECT_NAME}"

# Test directory
TEST_DIR="tests"
if [ -d "test" ] && [ ! -d "tests" ]; then
    TEST_DIR="test"
fi

# Pytest enabled
PYTEST_ENABLED="false"
if [ "${TEST_FRAMEWORK}" = "pytest" ]; then
    PYTEST_ENABLED="true"
fi

# Timestamp
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%S")

# ─── Display Configuration ───
echo ""
echo -e "${BLUE}  Detected Configuration:${NC}"
echo -e "  ─────────────────────────────────"
echo -e "  Project:      ${GREEN}${PROJECT_NAME}${NC}"
echo -e "  Tech Stack:   ${GREEN}${TECH_STACK}${NC}"
echo -e "  Test:         ${GREEN}${TEST_FRAMEWORK}${NC}"
echo -e "  Main Branch:  ${GREEN}${MAIN_BRANCH}${NC}"
echo -e "  Worktree:     ../${WORKTREE_PREFIX}-feat-xxx"
echo -e "  Parallel:     ${MAX_PARALLEL}"
echo ""

# ─── Confirm ───
if [ "${QUICK_MODE}" = false ]; then
    echo -ne "  Continue? (y/n) "
    read -r CONFIRM
    if [ "${CONFIRM}" != "y" ] && [ "${CONFIRM}" != "Y" ]; then
        echo "Aborted."
        exit 0
    fi
fi

# ─── Create Directories ───
echo ""
echo -e "${BLUE}  Creating directories...${NC}"
mkdir -p feature-workflow/templates
mkdir -p features/archive

echo -e "  ${GREEN}✓${NC} feature-workflow/"
echo -e "  ${GREEN}✓${NC} features/"
echo -e "  ${GREEN}✓${NC} features/archive/"

# ─── Generate config.yaml ───
echo ""
echo -e "${BLUE}  Generating configuration files...${NC}"

cat > "feature-workflow/config.yaml" << YAML
# Feature Workflow 配置
# 由 init-project 自动生成于 ${TIMESTAMP}

# 项目信息
project:
  name: ${PROJECT_NAME}
  main_branch: ${MAIN_BRANCH}
  repo_path: .

  tech_stack: ${TECH_STACK}

  test_framework: ${TEST_FRAMEWORK}

# 并行控制
parallelism:
  max_concurrent: ${MAX_PARALLEL}

# Git 设置
git:
  remote: origin
  auto_push: false
  merge_strategy: "--no-ff"
  push_tags: true

# 分支策略
branch_prefix: feature
worktree_prefix: ${WORKTREE_PREFIX}
worktree_base: ..

# 工作流设置
workflow:
  auto_start: false
  auto_start_next: true
  require_checklist: true
  subagent_timeout: 20             # SubAgent 超时阈值（分钟）

  # 需求切分
  splitting:
    enabled: true
    threshold: 3

  # 测试配置
  testing:
    pytest_enabled: ${PYTEST_ENABLED}
    test_dir: ${TEST_DIR}
    coverage_enabled: true
    coverage_target: 80

# 归档配置
completion:
  archive:
    create_tag: true
    tag_format: "{id}-{date}"
    tag_date_format: "%Y%m%d"

  cleanup:
    delete_worktree: true
    delete_branch: true

  record:
    update_spec: true
    update_archive_log: true

# 命名规则
naming:
  feature_prefix: feat
  branch_prefix: feature
  worktree_prefix: ${WORKTREE_PREFIX}

# 路径配置
paths:
  features_dir: features
  archive_dir: features/archive
  worktree_base: ..
  repo_path: .
YAML

echo -e "  ${GREEN}✓${NC} feature-workflow/config.yaml"

# ─── Generate queue.yaml ───
cat > "feature-workflow/queue.yaml" << YAML
# Feature 调度队列
# 此文件由 workflow 自动维护

meta:
  last_updated: "${TIMESTAMP}"
  version: 1

# 父需求（用于分组追踪)
parents: []

# 正在开发的需求
active: []

# 等待中的需求（按优先级排序）
pending: []

# 阻塞中的需求
blocked: []

# 已完成的需求
completed: []
YAML

echo -e "  ${GREEN}✓${NC} feature-workflow/queue.yaml"

# ─── Generate archive-log.yaml ───
cat > "features/archive/archive-log.yaml" << YAML
# Feature 归档日志
# 记录所有已完成的特性

meta:
  last_updated: "${TIMESTAMP}"
  version: 1
  total_completed: 0

# 已完成的特性
records: []
YAML

echo -e "  ${GREEN}✓${NC} features/archive/archive-log.yaml"

# ─── Generate project-context.md ───
cat > "project-context.md" << MD
---
last_updated: '${TIMESTAMP}'
version: 1
features_completed: 0
---

# Project Context: ${PROJECT_NAME}

> This file contains critical rules and patterns that AI agents must follow when implementing code.
> Run /pm-agent to perform deep analysis and fill in all sections.

---

## Technology Stack

| Category | Technology | Version | Notes |
|----------|-----------|---------|-------|
| Language | ${TECH_STACK} | - | Auto-detected |
| Testing | ${TEST_FRAMEWORK} | - | Auto-detected |

## Directory Structure

\`\`\`
${PROJECT_NAME}/
├── feature-workflow/
│   ├── config.yaml
│   ├── queue.yaml
│   └── templates/
├── features/
│   └── archive/
├── .claude/
│   ├── commands/
│   ├── agents/
│   └── skills/
└── project-context.md
\`\`\`

## Critical Rules

### Must Follow

- Run /pm-agent to auto-detect project rules

### Must Avoid

- Run /pm-agent to auto-detect anti-patterns

## Code Patterns

<!-- Run /pm-agent --fresh to auto-detect -->

## Testing Patterns

<!-- Run /pm-agent --fresh to auto-detect -->

## Recent Changes

| Date | Feature | Impact |
|------|---------|--------|
| - | Project initialized | - |

## Update Log

- ${TIMESTAMP}: Initial project context created (auto-generated)
MD

echo -e "  ${GREEN}✓${NC} project-context.md"

# ─── Copy Templates ───
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MARKETPLACE_DIR="$(dirname "${SCRIPT_DIR}")"
TEMPLATES_SRC="${MARKETPLACE_DIR}/plugins/feature-workflow/templates"

if [ -d "${TEMPLATES_SRC}" ]; then
    for tmpl in "${TEMPLATES_SRC}"/*.md; do
        [ -f "${tmpl}" ] || continue
        cp "${tmpl}" "feature-workflow/templates/"
    done
    echo -e "  ${GREEN}✓${NC} feature-workflow/templates/ ($(ls "${TEMPLATES_SRC}"/*.md 2>/dev/null | wc -l | tr -d ' ') templates)"
fi

# ─── Git Add ───
echo ""
echo -e "${BLUE}  Staging files in Git...${NC}"
git add feature-workflow/ features/ project-context.md 2>/dev/null || true
echo -e "  ${GREEN}✓${NC} Files staged (not committed)"

# ─── Summary ───
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Feature Workflow Initialized!${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Project:    ${GREEN}${PROJECT_NAME}${NC}"
echo -e "  Tech Stack: ${GREEN}${TECH_STACK}${NC}"
echo -e "  Test:       ${GREEN}${TEST_FRAMEWORK}${NC}"
echo -e "  Branch:     ${GREEN}${MAIN_BRANCH}${NC}"
echo -e "  Parallel:   ${MAX_PARALLEL}"
echo ""
echo -e "  ${BLUE}Next steps:${NC}"
echo -e "  1. Review:   ${GREEN}feature-workflow/config.yaml${NC}"
echo -e "  2. Context:  ${GREEN}/pm-agent${NC} (build full project context)"
echo -e "  3. Create:   ${GREEN}/new-feature${NC} (create your first feature)"
echo ""
