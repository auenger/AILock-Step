#!/usr/bin/env bash
# install-plugin.sh — 从 Marketplace 安装插件到目标项目
#
# 用法:
#   ./install-plugin.sh <project-path> [plugin-id]
#   ./install-plugin.sh /path/to/my-project feature-workflow
#   ./install-plugin.sh /path/to/my-project              # 默认安装 feature-workflow
#
# 功能:
#   1. 读取 marketplace.json 索引
#   2. 复制 commands → .claude/commands/
#   3. 复制 agents → .claude/agents/
#   4. 复制 skills → .claude/skills/
#   5. 复制 templates → feature-workflow/templates/ (如果存在)

set -euo pipefail

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Marketplace 根目录（脚本所在目录的父目录）
MARKETPLACE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PLUGINS_DIR="${MARKETPLACE_DIR}/plugins"

# 参数
TARGET_PROJECT="${1:-}"
PLUGIN_ID="${2:-feature-workflow}"

# 帮助信息
usage() {
    echo "Usage: $0 <project-path> [plugin-id]"
    echo ""
    echo "Available plugins:"
    # 列出所有可用插件
    for plugin_dir in "${PLUGINS_DIR}"/*/; do
        if [ -f "${plugin_dir}.claude-plugin/plugin.json" ]; then
            local plugin_name
            plugin_name=$(basename "${plugin_dir}")
            echo "  - ${plugin_name}"
        fi
    done
    exit 1
}

# 验证参数
if [ -z "${TARGET_PROJECT}" ]; then
    usage
fi

# 解析目标路径（支持相对路径）
TARGET_PROJECT="$(cd "${TARGET_PROJECT}" 2>/dev/null && pwd)" || {
    echo -e "${RED}Error: Project path does not exist: ${1}${NC}"
    exit 1
}

# 查找插件目录
PLUGIN_DIR="${PLUGINS_DIR}/${PLUGIN_ID}"
if [ ! -d "${PLUGIN_DIR}" ]; then
    echo -e "${RED}Error: Plugin '${PLUGIN_ID}' not found in marketplace${NC}"
    echo -e "${YELLOW}Available plugins:${NC}"
    ls -1 "${PLUGINS_DIR}" 2>/dev/null | sed 's/^/  - /'
    exit 1
fi

# 验证 plugin.json
PLUGIN_JSON="${PLUGIN_DIR}/.claude-plugin/plugin.json"
if [ ! -f "${PLUGIN_JSON}" ]; then
    echo -e "${RED}Error: plugin.json not found for '${PLUGIN_ID}'${NC}"
    exit 1
fi

echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Company AI Marketplace - Plugin Installer${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Plugin:    ${GREEN}${PLUGIN_ID}${NC}"
echo -e "  Target:    ${TARGET_PROJECT}"
echo ""

# 创建目标目录
mkdir -p "${TARGET_PROJECT}/.claude/commands"
mkdir -p "${TARGET_PROJECT}/.claude/agents"
mkdir -p "${TARGET_PROJECT}/.claude/skills"
mkdir -p "${TARGET_PROJECT}/feature-workflow/templates"

# 安装计数
INSTALLED=0
SKIPPED=0
OVERWRITTEN=0

# 安装函数
install_files() {
    local src_dir="$1"
    local dest_dir="$2"
    local type_name="$3"

    if [ ! -d "${src_dir}" ]; then
        return
    fi

    for file in "${src_dir}"/*.md; do
        [ -f "${file}" ] || continue

        local filename
        filename=$(basename "${file}")
        local dest_file="${dest_dir}/${filename}"

        if [ -f "${dest_file}" ]; then
            # 比较文件内容
            if diff -q "${file}" "${dest_file}" > /dev/null 2>&1; then
                echo -e "  ${YELLOW}⊘ ${type_name}/${filename}${NC} (identical, skipped)"
                ((SKIPPED++))
            else
                echo -e "  ${GREEN}↻ ${type_name}/${filename}${NC} (updated)"
                cp "${file}" "${dest_file}"
                ((OVERWRITTEN++))
            fi
        else
            echo -e "  ${GREEN}✓ ${type_name}/${filename}${NC} (installed)"
            cp "${file}" "${dest_file}"
            ((INSTALLED++))
        fi
    done
}

# 安装 Commands
echo -e "${BLUE}Installing Commands...${NC}"
install_files "${PLUGIN_DIR}/commands" "${TARGET_PROJECT}/.claude/commands" "commands"

# 安装 Agents
echo ""
echo -e "${BLUE}Installing Agents...${NC}"
install_files "${PLUGIN_DIR}/agents" "${TARGET_PROJECT}/.claude/agents" "agents"

# 安装 Skills
echo ""
echo -e "${BLUE}Installing Skills...${NC}"
install_files "${PLUGIN_DIR}/skills" "${TARGET_PROJECT}/.claude/skills" "skills"

# 安装 Templates（到 feature-workflow/templates/）
echo ""
echo -e "${BLUE}Installing Templates...${NC}"
install_files "${PLUGIN_DIR}/templates" "${TARGET_PROJECT}/feature-workflow/templates" "templates"

# 汇总
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Installation Complete!${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Installed:  ${GREEN}${INSTALLED}${NC} files"
echo -e "  Updated:    ${YELLOW}${OVERWRITTEN}${NC} files"
echo -e "  Skipped:    ${SKIPPED} files (unchanged)"
echo ""

# 检查是否需要初始化
if [ ! -f "${TARGET_PROJECT}/feature-workflow/config.yaml" ]; then
    echo -e "${YELLOW}  ⚠ Project not yet initialized${NC}"
    echo -e "  Run ${GREEN}/init-project${NC} in Claude Code to set up configuration."
else
    echo -e "  Project is initialized. Run ${GREEN}/list-features${NC} to get started."
fi

echo ""
