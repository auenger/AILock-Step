#!/usr/bin/env bash
# install-plugin.sh — 从 Marketplace 安装插件到目标项目
#
# 用法:
#   ./install-plugin.sh <project-path> [plugin-id]
#   ./install-plugin.sh /path/to/my-project feature-workflow
#   ./install-plugin.sh /path/to/my-project              # 默认安装 feature-workflow
#
# 功能:
#   1. 读取 marketplace.json 索引
#   2. 复制 commands → .claude/commands/
#   3. 复制 agents → .claude/agents/
#   4. 复制 skills → .claude/skills/ (目录格式: {name}/skill.md)
#   5. 复制 hooks → .claude/hooks/
#   6. 合并 settings.json hooks 配置
#   7. 复制 templates → feature-workflow/templates/

set -euo pipefail

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Marketplace 根目录（脚本所在目录的父目录）
MARKETPLACE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PLUGINS_DIR="${MARKETPLACE_DIR}/plugins"

# 参数
TARGET_PROJECT="${1:-}"
PLUGIN_ID="${2:-feature-workflow}"

# 帮助信息
usage() {
    echo "Usage: $0 <project-path> [plugin-id]"
    echo ""
    echo "Available plugins:"
    # 列出所有可用插件
    for plugin_dir in "${PLUGINS_DIR}"/*/; do
        if [ -f "${plugin_dir}.claude-plugin/plugin.json" ]; then
            local plugin_name
            plugin_name=$(basename "${plugin_dir}")
            echo "  - ${plugin_name}"
        fi
    done
    exit 1
}

# 验证参数
if [ -z "${TARGET_PROJECT}" ]; then
    usage
fi

# 解析目标路径（支持相对路径）
TARGET_PROJECT="$(cd "${TARGET_PROJECT}" 2>/dev/null && pwd)" || {
    echo -e "${RED}Error: Project path does not exist: ${1}${NC}"
    exit 1
}

# 查找插件目录
PLUGIN_DIR="${PLUGINS_DIR}/${PLUGIN_ID}"
if [ ! -d "${PLUGIN_DIR}" ]; then
    echo -e "${RED}Error: Plugin '${PLUGIN_ID}' not found in marketplace${NC}"
    echo -e "${YELLOW}Available plugins:${NC}"
    ls -1 "${PLUGINS_DIR}" 2>/dev/null | sed 's/^/  - /'
    exit 1
fi

# 验证 plugin.json
PLUGIN_JSON="${PLUGIN_DIR}/.claude-plugin/plugin.json"
if [ ! -f "${PLUGIN_JSON}" ]; then
    echo -e "${RED}Error: plugin.json not found for '${PLUGIN_ID}'${NC}"
    exit 1
fi

echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  Company AI Marketplace - Plugin Installer${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Plugin:    ${GREEN}${PLUGIN_ID}${NC}"
echo -e "  Target:    ${TARGET_PROJECT}"
echo ""

# 创建目标目录
mkdir -p "${TARGET_PROJECT}/.claude/commands"
mkdir -p "${TARGET_PROJECT}/.claude/agents"
mkdir -p "${TARGET_PROJECT}/.claude/skills"
mkdir -p "${TARGET_PROJECT}/feature-workflow/templates"

# 安装计数
INSTALLED=0
SKIPPED=0
OVERWRITTEN=0

# 安装函数
install_files() {
    local src_dir="$1"
    local dest_dir="$2"
    local type_name="$3"

    if [ ! -d "${src_dir}" ]; then
        return
    fi

    for file in "${src_dir}"/*.md; do
        [ -f "${file}" ] || continue

        local filename
        filename=$(basename "${file}")
        local dest_file="${dest_dir}/${filename}"

        if [ -f "${dest_file}" ]; then
            # 比较文件内容
            if diff -q "${file}" "${dest_file}" > /dev/null 2>&1; then
                echo -e "  ${YELLOW}⊘ ${type_name}/${filename}${NC} (identical, skipped)"
                SKIPPED=$((SKIPPED + 1))
            else
                echo -e "  ${GREEN}↻ ${type_name}/${filename}${NC} (updated)"
                cp "${file}" "${dest_file}"
                OVERWRITTEN=$((OVERWRITTEN + 1))
            fi
        else
            echo -e "  ${GREEN}✓ ${type_name}/${filename}${NC} (installed)"
            cp "${file}" "${dest_file}"
            INSTALLED=$((INSTALLED + 1))
        fi
    done
}

# 安装 Commands
echo -e "${BLUE}Installing Commands...${NC}"
install_files "${PLUGIN_DIR}/commands" "${TARGET_PROJECT}/.claude/commands" "commands"

# 安装 Agents
echo ""
echo -e "${BLUE}Installing Agents...${NC}"
install_files "${PLUGIN_DIR}/agents" "${TARGET_PROJECT}/.claude/agents" "agents"

# 安装 Skills（目录格式: skills/{name}/skill.md）
echo ""
echo -e "${BLUE}Installing Skills...${NC}"
if [ -d "${PLUGIN_DIR}/skills" ]; then
    for skill_dir in "${PLUGIN_DIR}/skills"/*/; do
        [ -d "${skill_dir}" ] || continue
        skill_name=$(basename "${skill_dir}")
        dest_skill_dir="${TARGET_PROJECT}/.claude/skills/${skill_name}"

        if [ -f "${skill_dir}/skill.md" ]; then
            mkdir -p "${dest_skill_dir}"
            if [ -f "${dest_skill_dir}/skill.md" ]; then
                if diff -q "${skill_dir}/skill.md" "${dest_skill_dir}/skill.md" > /dev/null 2>&1; then
                    echo -e "  ${YELLOW}⊘ skills/${skill_name}${NC} (identical, skipped)"
                    SKIPPED=$((SKIPPED + 1))
                else
                    echo -e "  ${GREEN}↻ skills/${skill_name}${NC} (updated)"
                    cp "${skill_dir}/skill.md" "${dest_skill_dir}/skill.md"
                    OVERWRITTEN=$((OVERWRITTEN + 1))
                fi
            else
                echo -e "  ${GREEN}✓ skills/${skill_name}${NC} (installed)"
                cp "${skill_dir}/skill.md" "${dest_skill_dir}/skill.md"
                INSTALLED=$((INSTALLED + 1))
            fi
        fi
    done
fi

# 安装 Templates（到 feature-workflow/templates/）
echo ""
echo -e "${BLUE}Installing Templates...${NC}"
install_files "${PLUGIN_DIR}/templates" "${TARGET_PROJECT}/feature-workflow/templates" "templates"

# 安装 Hooks（到 .claude/hooks/）
echo ""
echo -e "${BLUE}Installing Hooks...${NC}"
if [ -d "${PLUGIN_DIR}/hooks" ]; then
    mkdir -p "${TARGET_PROJECT}/.claude/hooks"
    for hook_file in "${PLUGIN_DIR}/hooks"/*.sh; do
        [ -f "${hook_file}" ] || continue
        hook_name=$(basename "${hook_file}")
        dest_hook="${TARGET_PROJECT}/.claude/hooks/${hook_name}"
        if [ -f "${dest_hook}" ]; then
            if diff -q "${hook_file}" "${dest_hook}" > /dev/null 2>&1; then
                echo -e "  ${YELLOW}⊘ hooks/${hook_name}${NC} (identical, skipped)"
                SKIPPED=$((SKIPPED + 1))
            else
                echo -e "  ${GREEN}↻ hooks/${hook_name}${NC} (updated)"
                cp "${hook_file}" "${dest_hook}"
                chmod +x "${dest_hook}"
                OVERWRITTEN=$((OVERWRITTEN + 1))
            fi
        else
            echo -e "  ${GREEN}✓ hooks/${hook_name}${NC} (installed)"
            cp "${hook_file}" "${dest_hook}"
            chmod +x "${dest_hook}"
            INSTALLED=$((INSTALLED + 1))
        fi
    done
fi

# 合并 settings.json hooks 配置
SETTINGS_FILE="${TARGET_PROJECT}/.claude/settings.json"
if [ -f "${SETTINGS_FILE}" ]; then
    echo -e "  ${YELLOW}⊘ settings.json${NC} (exists, manual merge may be needed)"
else
    cat > "${SETTINGS_FILE}" << 'SETTINGSJSON'
{
  "hooks": {
    "SubagentStop": [
      {
        "matcher": "Agent",
        "hooks": [
          {
            "type": "command",
            "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/on-subagent-complete.sh\""
          }
        ]
      }
    ],
    "Stop": [
      {
        "matcher": "",
        "hooks": [
          {
            "type": "command",
            "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/on-stop-check.sh\""
          }
        ]
      }
    ]
  }
}
SETTINGSJSON
    echo -e "  ${GREEN}✓ settings.json${NC} (created with hooks config)"
fi

# 汇总
echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Installation Complete!${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Installed:  ${GREEN}${INSTALLED}${NC} files"
echo -e "  Updated:    ${YELLOW}${OVERWRITTEN}${NC} files"
echo -e "  Skipped:    ${SKIPPED} files (unchanged)"
echo ""

# 检查是否需要初始化
if [ ! -f "${TARGET_PROJECT}/feature-workflow/config.yaml" ]; then
    echo -e "${YELLOW}  ⚠ Project not yet initialized${NC}"
    echo -e "  Run ${GREEN}/init-project${NC} in Claude Code to set up configuration."
else
    echo -e "  Project is initialized. Run ${GREEN}/list-features${NC} to get started."
fi

echo ""
