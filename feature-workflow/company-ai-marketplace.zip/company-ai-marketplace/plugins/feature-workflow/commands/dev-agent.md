# /dev-agent — Feature Development Entry Point

Automated feature development command. Reads the feature queue, evaluates dependencies, and dispatches DevSubAgent(s) to execute features.

## Usage

```
/dev-agent                      # Batch mode: schedule all pending features
/dev-agent <feature-id>         # Single mode: execute one specific feature
/dev-agent --resume             # Resume mode: continue interrupted features
/dev-agent --no-complete        # Execute start→implement→verify only (skip complete)
```

## Pre-flight

1. Read `feature-workflow/config.yaml` — get `parallelism.max_concurrent`, naming conventions
2. Read `feature-workflow/queue.yaml` — get active, pending, blocked, completed lists
3. Read `features/archive/archive-log.yaml` — for dependency checking

## Execution

### Mode 1: Single Feature (`/dev-agent <feature-id>`)

1. Verify `<feature-id>` exists in `queue.yaml` (pending or active)
2. Check dependencies satisfied (all deps in `archive-log.yaml`)
3. Check parallelism: `active.count < max_concurrent`
4. Launch **one DevSubAgent** via Agent Tool (foreground):
   - Inject: `FEATURE_ID`, `FEATURE_NAME`, `MODE` (full or no-complete)
5. Collect result, display summary

### Mode 2: Batch Mode (`/dev-agent`)

**Loop:**

```
1. READ STATE
   ├── queue.yaml → active count, pending list
   └── config.yaml → max_concurrent

2. EVALUATE CANDIDATES
   ├── Filter pending: all dependencies satisfied? parent ok? no active children?
   ├── Sort by priority (descending)
   └── slots = max_concurrent - active.count

3. PICK BATCH
   └── batch = candidates[:slots]
       ├── batch empty + pending not empty → all blocked, report and exit
       └── batch empty + pending empty → all done, report and exit

4. LAUNCH SUBAGENTS
   ├── batch.size > 1 → launch all with Agent Tool (parallel)
   └── batch.size == 1 → launch one with Agent Tool (foreground)

5. COLLECT RESULTS
   ├── status == "success" → feature already merged/tagged/archived by SubAgent
   │   → log to summary
   └── status == "error" → log diagnostics, continue other features

6. AUTO-LOOP
   ├── Check workflow.auto_start_next in config.yaml
   ├── If true AND pending not empty → go back to step 1
   └── Otherwise → output final summary, exit
```

### Mode 3: Resume (`/dev-agent --resume`)

1. Read `queue.yaml` active list
2. For each active feature, check progress:
   - `task.md` has incomplete tasks → resume from implement
   - `task.md` complete, checklist unverified → resume from verify
   - Code committed but not merged → resume from complete
   - Worktree missing → skip, warn user
3. Launch DevSubAgent(s) for resumable features

## Agent Tool Call Format

```
Agent Tool:
  subagent_type: "dev-subagent"
  description: "DevSubAgent: {feature_id} - {feature_name}"
  run_in_background: true  (when batch > 1)

  prompt: |
    FEATURE_ID: {id}
    FEATURE_NAME: {name}
    MODE: {full | no-complete}
    RETRY_LIMIT: 2
```

## Output

### Single Feature

```
✅ feat-auth completed! (15 min)

  ✅ start-feature    → branch: feature/auth, worktree: ../AnyClaw-auth
  ✅ implement-feature → 5/5 tasks
  ✅ verify-feature   → 12 tests passed
  ✅ complete-feature → tag: feat-auth-20260330, merged to main
```

### Batch Summary

```
📊 Batch Complete

✅ Succeeded (2):
   - feat-auth (15 min) → feat-auth-20260330
   - feat-dashboard (22 min) → feat-dashboard-20260330

❌ Failed (1):
   - feat-export → error at implement (task 3), re-queued

Queue: 0 active, 1 pending, 0 blocked
```

## Error Handling

| Scenario | Action |
|----------|--------|
| SubAgent returns error | Log diagnostics, re-queue feature, continue loop |
| All pending blocked | Report blocked features, pause for user |
| queue.yaml corrupted | Stop, report error |
| config.yaml not found | Stop, report error |
